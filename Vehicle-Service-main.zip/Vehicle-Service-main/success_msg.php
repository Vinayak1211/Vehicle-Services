<style>
    #uni_modal .modal-footer,#uni_modal .modal-header{
        display:none
    }
</style>
<div class="container-fluid">
    <p>Your Request was submitted successfully. The management will contact you as soon as they sees your request. Thank you!</p>
    <div class="w-100 d-flex justify-content-end mx-2">
        <div class="col-auto">
            <button class="btn btn-dark btn-sm rounded-0" type="button" data-dismiss="modal">Close</button>
        </div>
    </div>
</div>